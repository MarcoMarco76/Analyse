# 📡 LynchScreener

**Analyseur boursier temps réel basé sur la méthode Peter Lynch**
Marchés 🇺🇸 NYSE/NASDAQ et 🇨🇦 TSX — Propulsé par Claude AI + Web Search

---

## ✨ Fonctionnalités

- Analyse IA en temps réel (web search via Claude Sonnet)
- Score 1–100 selon 7 critères Peter Lynch
- 6 catégories : FastGrower, Stalwart, Cyclical, TurnaroundPlay, AssetPlay, SlowGrower
- Gradients rouge→vert selon le score
- ⭐ Top Picks automatiques (score ≥ 80)
- Badge 👤 si achats insiders détectés
- Tri par score, PEG, croissance, secteur
- Filtre par catégorie Lynch et score minimum
- Bourse US (NYSE/NASDAQ) et canadienne (TSX)

---

## 🔑 Prérequis

1. Un compte **GitHub** — [github.com](https://github.com) (gratuit)
2. Un compte **Vercel** — [vercel.com](https://vercel.com) (gratuit)
3. Une clé **API Anthropic** — [console.anthropic.com](https://console.anthropic.com) (payant à l'usage, ~$0.003/analyse)

---

## 🚀 Déploiement Vercel — Pas à pas

### ÉTAPE 1 — Obtenir votre clé API Anthropic

1. Allez sur [console.anthropic.com](https://console.anthropic.com)
2. Créez un compte ou connectez-vous
3. Cliquez sur **API Keys** dans le menu gauche
4. Cliquez **Create Key**
5. Donnez-lui un nom (ex: "lynch-screener")
6. **Copiez la clé** — elle commence par `sk-ant-api03-...`
   ⚠️ Elle ne sera affichée qu'une seule fois !
7. Rechargez quelques dollars de crédit dans **Billing** (ex: $10)

---

### ÉTAPE 2 — Mettre le projet sur GitHub

**Option A — Interface GitHub (sans ligne de commande)**

1. Allez sur [github.com](https://github.com) et connectez-vous
2. Cliquez sur le **+** en haut à droite → **New repository**
3. Nom du dépôt : `lynch-screener`
4. Cochez **Private** (recommandé)
5. Cliquez **Create repository**
6. Sur la page du dépôt vide, cliquez **uploading an existing file**
7. Glissez-déposez **tous les fichiers du projet** (respectez la structure des dossiers)
8. Cliquez **Commit changes**

**Option B — Terminal (si vous avez Git installé)**

```bash
# Dans le dossier du projet lynch-screener/
git init
git add .
git commit -m "Initial commit — LynchScreener"
git branch -M main
git remote add origin https://github.com/VOTRE_USERNAME/lynch-screener.git
git push -u origin main
```

---

### ÉTAPE 3 — Déployer sur Vercel

1. Allez sur [vercel.com](https://vercel.com) et connectez-vous avec votre compte GitHub
2. Cliquez **Add New… → Project**
3. Trouvez et cliquez **Import** à côté de `lynch-screener`
4. Vercel détecte automatiquement que c'est un projet Next.js ✅
5. **NE CLIQUEZ PAS encore sur Deploy** — d'abord les variables d'environnement

---

### ÉTAPE 4 — Configurer la clé API (IMPORTANT)

Toujours sur la page de configuration Vercel, avant de déployer :

1. Ouvrez la section **Environment Variables**
2. Remplissez :
   - **Name** : `ANTHROPIC_API_KEY`
   - **Value** : `sk-ant-api03-VOTRE_CLE_ICI`
3. Laissez les environnements cochés : ✅ Production ✅ Preview ✅ Development
4. Cliquez **Add**

---

### ÉTAPE 5 — Déployer !

1. Cliquez **Deploy**
2. Attendez ~60 secondes que Vercel compile le projet
3. 🎉 Votre application est en ligne !
4. Vercel vous donne une URL du type : `https://lynch-screener-xxxx.vercel.app`

---

### ÉTAPE 6 — Personnaliser votre domaine (optionnel)

Dans le tableau de bord Vercel de votre projet :
- **Settings → Domains** → ajoutez votre domaine personnalisé
- Ou renommez le sous-domaine Vercel dans **Settings → Domains**

---

## 💻 Développement local

```bash
# 1. Cloner le dépôt
git clone https://github.com/VOTRE_USERNAME/lynch-screener.git
cd lynch-screener

# 2. Installer les dépendances
npm install

# 3. Créer le fichier de variables d'environnement
cp .env.example .env.local

# 4. Ouvrir .env.local et y coller votre clé
#    ANTHROPIC_API_KEY=sk-ant-VOTRE_CLE_ICI

# 5. Lancer le serveur de développement
npm run dev
# → Application disponible sur http://localhost:3000
```

---

## 📁 Structure du projet

```
lynch-screener/
├── pages/
│   ├── _app.jsx           # App wrapper (CSS global)
│   ├── index.jsx          # Page principale + logique screener
│   └── api/
│       └── analyze.js     # 🔒 Route API sécurisée (clé Anthropic côté serveur)
├── components/
│   ├── StockCard.jsx      # Carte action avec score coloré
│   ├── StockModal.jsx     # Modal détail avec décomposition
│   ├── WelcomeScreen.jsx  # Écran d'accueil avec légendes
│   ├── MetricCell.jsx     # Cellule métrique réutilisable
│   └── ScoreBar.jsx       # Barre de progression scoring
├── lib/
│   └── data.js            # Secteurs, catégories, helpers
├── styles/
│   └── globals.css        # Styles globaux (terminal financier)
├── .env.example           # Template variables d'environnement
├── .gitignore             # Exclut node_modules et .env.local
├── next.config.js
└── package.json
```

---

## 💰 Coût estimé

| Action                    | Coût approximatif |
|---------------------------|-------------------|
| 1 secteur analysé (5 titres) | ~$0.01–0.03   |
| Scan complet US (8 secteurs) | ~$0.10–0.25   |
| Scan complet CA (8 secteurs) | ~$0.10–0.25   |
| Scan complet US + CA         | ~$0.20–0.50   |

Les coûts varient selon la longueur des recherches web effectuées par Claude.

---

## 🔒 Sécurité

- La clé API **ne transite jamais** vers le navigateur
- Elle est lue uniquement dans `pages/api/analyze.js` (côté serveur Node.js)
- Le fichier `.env.local` est exclu du dépôt Git par `.gitignore`
- Sur Vercel, la clé est stockée chiffrée dans leurs serveurs

---

## ⚠️ Avertissement légal

Cette application génère des analyses financières à titre **éducatif uniquement**.
Elle ne constitue pas un conseil en investissement.
Consultez un conseiller financier agréé avant toute décision d'investissement.

---

## 🛠️ Dépannage

**Erreur "Clé API manquante"**
→ Vérifiez que `ANTHROPIC_API_KEY` est bien définie dans Vercel (Settings → Environment Variables)
→ Après modification des variables, re-déployez (Deployments → Redeploy)

**Erreur "HTTP 529" ou "overloaded"**
→ Les serveurs Anthropic sont surchargés, réessayez dans quelques minutes

**Le scan prend trop longtemps**
→ Normal ! Chaque secteur effectue ~5 recherches web. Comptez 30–90s par secteur.
→ Commencez avec 2–3 secteurs pour tester.

**L'application plante après le déploiement**
→ Vérifiez les logs dans Vercel → votre projet → Deployments → Functions Logs

---

*LynchScreener — Construit avec Next.js, React et l'API Anthropic Claude*
