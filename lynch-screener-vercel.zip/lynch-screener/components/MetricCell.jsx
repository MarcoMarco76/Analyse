export default function MetricCell({ label, value, highlight }) {
  return (
    <div style={{ background: '#060e1a', borderRadius: 6, padding: '6px 8px', textAlign: 'center' }}>
      <div style={{ color: '#2a4a68', fontSize: 9, marginBottom: 2, textTransform: 'uppercase', letterSpacing: .5 }}>{label}</div>
      <div className="fm" style={{ color: highlight ? '#4ade80' : '#b8cde3', fontSize: 12, fontWeight: 700 }}>
        {value ?? '—'}
      </div>
    </div>
  );
}
