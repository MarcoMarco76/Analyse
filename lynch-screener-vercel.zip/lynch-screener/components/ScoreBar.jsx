export default function ScoreBar({ label, pts, max }) {
  const pct = max > 0 ? (pts / max) * 100 : 0;
  const c   = pct >= 70 ? '#4ade80' : pct >= 40 ? '#facc15' : '#f87171';
  return (
    <div style={{ marginBottom: 9 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 3 }}>
        <span style={{ color: '#7a9bb8', fontSize: 12 }}>{label}</span>
        <span className="fm" style={{ color: c, fontSize: 12, fontWeight: 700 }}>{pts}/{max}</span>
      </div>
      <div style={{ background: '#0f2135', borderRadius: 3, height: 3, overflow: 'hidden' }}>
        <div style={{ width: `${pct}%`, height: '100%', background: c, borderRadius: 3, transition: 'width .8s ease' }} />
      </div>
    </div>
  );
}
