import { scoreColor, scoreGlow, scoreLabel, fmt, pct, LYNCH_CATEGORIES, SECTOR_ICONS } from '../lib/data';
import MetricCell from './MetricCell';

export default function StockCard({ stock, idx, onClick }) {
  const c   = scoreColor(stock.score);
  const g   = scoreGlow(stock.score);
  const cat = LYNCH_CATEGORIES[stock.lynchCategory] || LYNCH_CATEGORIES.Stalwart;
  const priceLabel = stock.price ? `${stock.currency === 'CAD' ? 'C$' : '$'}${fmt(stock.price, 2)}` : '—';
  const isTop      = stock.score >= 80;
  const hasInsider = (stock.scoreBreakdown?.insider || 0) >= 8 ||
                     (stock.insiderActivity || '').toLowerCase().includes('achat');

  return (
    <div
      className="card"
      style={{ '--sc': c, '--sg': g, '--sd': c + '55', animationDelay: `${Math.min(idx * .055, 1.1)}s`, cursor: 'pointer' }}
      onClick={onClick}
    >
      {isTop && (
        <div style={{
          position: 'absolute', top: 8, right: 8,
          background: '#f59e0b18', border: '1px solid #f59e0b44',
          borderRadius: 4, padding: '2px 7px',
          fontSize: 9, color: '#f59e0b', fontWeight: 700, letterSpacing: .5,
        }}>⭐ TOP</div>
      )}

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', paddingRight: isTop ? 52 : 0 }}>
        <div>
          <div className="fm" style={{ fontSize: 16, fontWeight: 700, color: '#eaf2fb', letterSpacing: '-.5px' }}>{stock.ticker}</div>
          <div style={{ fontSize: 11, color: '#3a5a78', marginTop: 2, maxWidth: 155, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{stock.name}</div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div className="fm fn" style={{ fontSize: 24, color: c, lineHeight: 1, fontWeight: 700 }}>{stock.score}</div>
          <div style={{ fontSize: 9, color: c, fontWeight: 700, letterSpacing: .6, marginTop: 1 }}>{scoreLabel(stock.score)}</div>
        </div>
      </div>

      <div className="sbar"><div className="sfill" style={{ width: `${stock.score}%` }} /></div>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
        <span className="fm" style={{ color: '#5a9fd4', fontSize: 13 }}>{priceLabel}</span>
        <span style={{ background: '#0c1e33', color: '#2d4f6b', fontSize: 9, padding: '2px 7px', borderRadius: 4, letterSpacing: .3 }}>
          {SECTOR_ICONS[stock.sector] || '📊'} {stock.sector}
        </span>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 5 }}>
        <MetricCell label="PEG"     value={stock.pegRatio != null ? fmt(stock.pegRatio, 1) : null}         highlight={stock.pegRatio < 1} />
        <MetricCell label="P/E"     value={stock.peRatio  != null ? fmt(stock.peRatio,  0) : null} />
        <MetricCell label="Crois.%" value={stock.earningsGrowth != null ? pct(stock.earningsGrowth) : null} highlight={stock.earningsGrowth > 15} />
      </div>

      <div style={{ display: 'flex', alignItems: 'center', marginTop: 10, gap: 6 }}>
        <span style={{ fontSize: 10, color: cat.color, fontWeight: 500 }}>{cat.icon} {cat.label}</span>
        {hasInsider && (
          <span style={{ marginLeft: 'auto', background: '#00e09a14', color: '#00e09a', fontSize: 9, padding: '2px 6px', borderRadius: 4, fontWeight: 700, letterSpacing: .3 }}>
            👤 INSIDER
          </span>
        )}
      </div>
    </div>
  );
}
