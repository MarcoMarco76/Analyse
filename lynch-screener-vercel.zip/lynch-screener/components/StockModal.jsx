import { useEffect } from 'react';
import { scoreColor, scoreLabel, fmt, pct, LYNCH_CATEGORIES } from '../lib/data';
import ScoreBar from './ScoreBar';

export default function StockModal({ stock, onClose }) {
  const c   = scoreColor(stock.score);
  const cat = LYNCH_CATEGORIES[stock.lynchCategory] || LYNCH_CATEGORIES.Stalwart;
  const sb  = stock.scoreBreakdown || {};
  const priceLabel = stock.price ? `${stock.currency === 'CAD' ? 'C$' : '$'}${fmt(stock.price, 2)}` : '—';

  useEffect(() => {
    const handler = e => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  const metrics = [
    ['Ratio PEG',             fmt(stock.pegRatio,    2)],
    ['P/E Ratio',             fmt(stock.peRatio,     1)],
    ['Croissance bénéfices',  pct(stock.earningsGrowth)],
    ['Croissance revenus',    pct(stock.revenueGrowth)],
    ['Dette / Cap. propres',  fmt(stock.debtToEquity, 2)],
    ['Flux trésorerie libre', stock.freeCashFlow],
    ['Activité insiders',     stock.insiderActivity],
  ].filter(([, v]) => v && v !== '—');

  return (
    <div className="overlay" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>

        {/* En-tête */}
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 20, paddingBottom: 16, borderBottom: '1px solid #102038' }}>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 5 }}>
              <span className="fm fn" style={{ fontSize: 26, color: '#eaf2fb' }}>{stock.ticker}</span>
              <span style={{ background: c + '1a', color: c, padding: '4px 10px', borderRadius: 6, fontSize: 13, fontWeight: 700 }}>{stock.score}/100</span>
              <span style={{ background: c + '14', color: c, padding: '3px 9px', borderRadius: 5, fontSize: 10, fontWeight: 700, letterSpacing: .5 }}>{scoreLabel(stock.score)}</span>
            </div>
            <div style={{ color: '#7a9bb8', fontSize: 14, marginBottom: 4 }}>{stock.name}</div>
            <div style={{ color: cat.color, fontSize: 12, fontWeight: 500 }}>
              {cat.icon} {cat.label} — <span style={{ color: '#3a5a78', fontWeight: 400 }}>{cat.desc}</span>
            </div>
          </div>
          <div style={{ textAlign: 'right' }}>
            <div className="fm" style={{ color: '#5a9fd4', fontSize: 17, fontWeight: 700 }}>{priceLabel}</div>
            <button onClick={onClose} style={{ background: 'transparent', border: 'none', color: '#2a4a68', fontSize: 18, cursor: 'pointer', marginTop: 8, display: 'block', marginLeft: 'auto' }}>✕</button>
          </div>
        </div>

        {/* Score Breakdown */}
        <div style={{ marginBottom: 20 }}>
          <div style={{ color: '#2a4a68', fontSize: 10, fontWeight: 600, letterSpacing: 1, marginBottom: 12, textTransform: 'uppercase' }}>Décomposition du score Peter Lynch</div>
          <ScoreBar label="Ratio PEG"                     pts={sb.peg            ?? 0} max={25} />
          <ScoreBar label="Croissance des bénéfices"      pts={sb.earningsGrowth ?? 0} max={20} />
          <ScoreBar label="Ratio dette / capitaux propres" pts={sb.debtEquity    ?? 0} max={15} />
          <ScoreBar label="P/E vs secteur"                 pts={sb.peVsSector    ?? 0} max={15} />
          <ScoreBar label="Croissance des revenus"         pts={sb.revenueGrowth ?? 0} max={10} />
          <ScoreBar label="Achats des insiders"            pts={sb.insider       ?? 0} max={10} />
          <ScoreBar label="Flux de trésorerie libre"       pts={sb.cashFlow      ?? 0} max={5}  />
          <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 14, padding: '12px 14px', background: c + '10', borderRadius: 8, border: `1px solid ${c}28` }}>
            <span className="fn" style={{ fontSize: 14, color: '#dde6f0' }}>SCORE TOTAL</span>
            <span className="fm fn" style={{ fontSize: 22, color: c }}>{stock.score} / 100</span>
          </div>
        </div>

        {/* Métriques */}
        {metrics.length > 0 && (
          <div style={{ marginBottom: 20 }}>
            <div style={{ color: '#2a4a68', fontSize: 10, fontWeight: 600, letterSpacing: 1, marginBottom: 10, textTransform: 'uppercase' }}>Métriques clés</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 7 }}>
              {metrics.map(([l, v]) => (
                <div key={l} style={{ background: '#060e1a', borderRadius: 8, padding: '9px 11px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                  <span style={{ color: '#3a5a78', fontSize: 11 }}>{l}</span>
                  <span className="fm" style={{ color: '#b8cde3', fontSize: 12, fontWeight: 700 }}>{v}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Thèse Lynch */}
        {stock.summary && (
          <div style={{ marginBottom: 20 }}>
            <div style={{ color: '#2a4a68', fontSize: 10, fontWeight: 600, letterSpacing: 1, marginBottom: 8, textTransform: 'uppercase' }}>Thèse d'investissement Lynch</div>
            <p style={{ color: '#7a9bb8', fontSize: 13, lineHeight: 1.75, background: '#060e1a', padding: '12px 14px', borderRadius: 8, borderLeft: `3px solid ${c}` }}>
              {stock.summary}
            </p>
          </div>
        )}

        {/* Points forts & Risques */}
        {((stock.highlights?.length > 0) || (stock.risks?.length > 0)) && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14, marginBottom: 20 }}>
            {stock.highlights?.length > 0 && (
              <div>
                <div style={{ color: '#2a4a68', fontSize: 10, fontWeight: 600, letterSpacing: 1, marginBottom: 8, textTransform: 'uppercase' }}>✅ Points forts</div>
                {stock.highlights.map((h, i) => (
                  <div key={i} style={{ color: '#4ade80', fontSize: 12, padding: '4px 0', borderBottom: '1px solid #0f2135' }}>→ {h}</div>
                ))}
              </div>
            )}
            {stock.risks?.length > 0 && (
              <div>
                <div style={{ color: '#2a4a68', fontSize: 10, fontWeight: 600, letterSpacing: 1, marginBottom: 8, textTransform: 'uppercase' }}>⚠️ Risques</div>
                {stock.risks.map((r, i) => (
                  <div key={i} style={{ color: '#fb923c', fontSize: 12, padding: '4px 0', borderBottom: '1px solid #0f2135' }}>→ {r}</div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Disclaimer */}
        <div style={{ padding: '9px 12px', background: '#0f213540', borderRadius: 6, color: '#2a4a68', fontSize: 10, lineHeight: 1.5 }}>
          ⚠️ Analyse générée par intelligence artificielle à titre éducatif uniquement. Ne constitue pas un conseil en investissement.
          Consultez un conseiller financier agréé avant toute décision d'investissement.
        </div>
      </div>
    </div>
  );
}
