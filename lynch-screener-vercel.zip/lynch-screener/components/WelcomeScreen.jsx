import { LYNCH_CATEGORIES } from '../lib/data';

const COLOR_SCALE = [
  [82, '#00e09a', '82–100\nExcellent'],
  [70, '#4ade80', '70–81\nTrès bon'],
  [60, '#a3e635', '60–69\nBon'],
  [50, '#facc15', '50–59\nMoyen'],
  [38, '#fb923c', '38–49\nFaible'],
  [0,  '#ef4444', '0–37\nÉviter'],
];
const SCORE_GRID = [
  ['Ratio PEG',             '25 pts', '#0ea5e9'],
  ['Croissance bénéfices',  '20 pts', '#10b981'],
  ['Dette / Cap. propres',  '15 pts', '#8b5cf6'],
  ['P/E vs Secteur',        '15 pts', '#f59e0b'],
  ['Croissance revenus',    '10 pts', '#ef4444'],
  ['Achats insiders',       '10 pts', '#06b6d4'],
  ['Flux trésorerie libre',  '5 pts', '#84cc16'],
];

export default function WelcomeScreen() {
  return (
    <div style={{ textAlign: 'center', padding: '56px 24px' }}>
      <div style={{ fontSize: 50, marginBottom: 16 }}>📡</div>
      <h2 className="fn" style={{ fontSize: 22, color: '#c8dcf0', marginBottom: 10, letterSpacing: '-.5px' }}>
        LynchScreener — Prêt à analyser
      </h2>
      <p style={{ color: '#2a4a68', fontSize: 14, maxWidth: 500, margin: '0 auto 36px', lineHeight: 1.8 }}>
        Sélectionnez vos secteurs, choisissez votre marché et lancez l'analyse pour découvrir les perles
        cachées du moment selon la méthode <strong style={{ color: '#5a9fd4' }}>Peter Lynch</strong>.
      </p>

      {/* Catégories Lynch */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(160px,1fr))', gap: 10, maxWidth: 640, margin: '0 auto 36px' }}>
        {Object.entries(LYNCH_CATEGORIES).map(([k, v]) => (
          <div key={k} style={{ background: '#0a1828', border: '1px solid #102038', borderRadius: 10, padding: '14px 12px', borderTop: `2px solid ${v.color}44` }}>
            <div style={{ fontSize: 20, marginBottom: 5 }}>{v.icon}</div>
            <div className="fn" style={{ color: '#c8dcf0', fontSize: 11, marginBottom: 3 }}>{v.label}</div>
            <div style={{ color: '#2a4a68', fontSize: 10 }}>{v.desc}</div>
          </div>
        ))}
      </div>

      {/* Grille scoring */}
      <div style={{ background: '#0a1828', border: '1px solid #102038', borderRadius: 12, padding: '20px 22px', maxWidth: 580, margin: '0 auto', textAlign: 'left' }}>
        <div style={{ color: '#2a4a68', fontSize: 10, fontWeight: 600, letterSpacing: 1, marginBottom: 14, textTransform: 'uppercase' }}>
          Grille de scoring — Méthode Peter Lynch
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '5px 20px' }}>
          {SCORE_GRID.map(([l, p, c]) => (
            <div key={l} style={{ display: 'flex', justifyContent: 'space-between', padding: '5px 0', borderBottom: '1px solid #0f213580' }}>
              <span style={{ color: '#7a9bb8', fontSize: 12 }}>{l}</span>
              <span className="fm" style={{ color: c, fontSize: 11, fontWeight: 700 }}>{p}</span>
            </div>
          ))}
        </div>

        {/* Échelle de couleur */}
        <div style={{ marginTop: 18 }}>
          <div style={{ color: '#2a4a68', fontSize: 10, fontWeight: 600, letterSpacing: 1, marginBottom: 8, textTransform: 'uppercase' }}>Échelle de couleur</div>
          <div style={{ display: 'flex', gap: 5 }}>
            {COLOR_SCALE.map(([s, c, lbl]) => (
              <div key={s} style={{ flex: 1, background: c + '18', border: `1px solid ${c}44`, borderRadius: 5, padding: '6px 4px', textAlign: 'center' }}>
                <div style={{ fontSize: 9, color: c, fontWeight: 700, whiteSpace: 'pre-line', lineHeight: 1.4 }}>{lbl}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
