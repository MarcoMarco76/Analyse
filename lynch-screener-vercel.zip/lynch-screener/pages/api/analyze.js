// ─────────────────────────────────────────────────────────────
// pages/api/analyze.js
// Route API Next.js — proxy sécurisé vers Anthropic
// La clé ANTHROPIC_API_KEY reste côté serveur, jamais exposée.
// ─────────────────────────────────────────────────────────────

export default async function handler(req, res) {
  // Méthode POST uniquement
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Méthode non autorisée' });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return res.status(500).json({
      error: 'Clé API Anthropic manquante. Vérifiez la variable ANTHROPIC_API_KEY dans Vercel.',
    });
  }

  const { sector, tickers, market } = req.body;
  if (!sector || !tickers || !market) {
    return res.status(400).json({ error: 'Paramètres manquants : sector, tickers, market' });
  }

  const currency = market === 'US' ? 'USD' : 'CAD';
  const exchange = market === 'US' ? 'NYSE/NASDAQ' : 'TSX Toronto';
  const top      = tickers.slice(0, 5);

  const prompt = `Tu es un analyste financier expert formé à la méthode Peter Lynch (One Up on Wall Street).

Effectue des recherches web pour obtenir les données financières actuelles de ces ${top.length} actions du secteur "${sector}" sur ${exchange}: ${top.join(', ')}

Calcule un score de 1 à 100 selon ces critères Peter Lynch:

CRITÈRE 1 — RATIO PEG (25 pts max):
  PEG < 0.5 → 25 pts | 0.5–1.0 → 20 pts | 1.0–1.5 → 12 pts | 1.5–2.0 → 5 pts | >2.0 → 0 pt
  (PEG = P/E ÷ taux de croissance bénéfices. Lynch préfère PEG < 1)

CRITÈRE 2 — CROISSANCE BÉNÉFICES YOY (20 pts max):
  >25% → 20 | 15–25% → 15 | 10–15% → 10 | 5–10% → 5 | <5% → 0

CRITÈRE 3 — DETTE/CAPITAUX PROPRES (15 pts max):
  <0.3 → 15 | 0.3–0.5 → 12 | 0.5–1.0 → 8 | 1.0–2.0 → 3 | >2.0 → 0

CRITÈRE 4 — VALORISATION vs SECTEUR P/E (15 pts max):
  Fortement sous-évalué → 15 | Sous-évalué → 12 | Juste prix → 8 | Légèrement surévalué → 3 | Très surévalué → 0

CRITÈRE 5 — CROISSANCE REVENUS (10 pts max):
  >20% → 10 | 10–20% → 7 | 5–10% → 4 | <5% → 0

CRITÈRE 6 — ACHATS INSIDERS (10 pts max):
  Achats nets significatifs récents → 10 | Achats modérés → 7 | Neutre → 4 | Ventes nettes → 0

CRITÈRE 7 — FLUX TRÉSORERIE LIBRE (5 pts max):
  FCF positif et en croissance → 5 | FCF positif → 3 | FCF négatif → 0

CATÉGORIE LYNCH (choisir 1): FastGrower | Stalwart | Cyclical | TurnaroundPlay | AssetPlay | SlowGrower

Retourne UNIQUEMENT ce tableau JSON valide, sans backticks, sans texte avant ou après:
[{
  "ticker": "XX",
  "name": "Nom Société",
  "sector": "${sector}",
  "price": 0.00,
  "currency": "${currency}",
  "score": 0,
  "pegRatio": 0.0,
  "peRatio": 0.0,
  "earningsGrowth": 0.0,
  "revenueGrowth": 0.0,
  "debtToEquity": 0.0,
  "freeCashFlow": "positif",
  "insiderActivity": "neutre",
  "lynchCategory": "FastGrower",
  "scoreBreakdown": {
    "peg": 0, "earningsGrowth": 0, "debtEquity": 0,
    "peVsSector": 0, "revenueGrowth": 0, "insider": 0, "cashFlow": 0
  },
  "highlights": ["point1","point2","point3"],
  "risks": ["risque1","risque2"],
  "summary": "Thèse Lynch en 2 phrases."
}]`;

  try {
    const anthropicRes = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: 4000,
        tools: [{ type: 'web_search_20250305', name: 'web_search' }],
        system: 'Tu es un analyste financier. Après tes recherches, réponds UNIQUEMENT avec du JSON valide, aucun texte supplémentaire.',
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    if (!anthropicRes.ok) {
      const errBody = await anthropicRes.json().catch(() => ({}));
      return res.status(anthropicRes.status).json({
        error: errBody.error?.message || `Erreur Anthropic HTTP ${anthropicRes.status}`,
      });
    }

    const data = await anthropicRes.json();
    const txt  = (data.content || []).filter(b => b.type === 'text').map(b => b.text).join('');
    const m    = txt.match(/\[[\s\S]*\]/);
    if (!m) return res.status(502).json({ error: 'Réponse JSON introuvable dans la réponse IA' });

    const stocks = JSON.parse(m[0]).filter(s => s && s.ticker);
    return res.status(200).json({ stocks });

  } catch (err) {
    console.error('[analyze API]', err);
    return res.status(500).json({ error: err.message || 'Erreur serveur interne' });
  }
}

// Augmenter le timeout Vercel pour les analyses longues (web search)
export const config = {
  api: { responseLimit: false },
  maxDuration: 60,
};
