import Head from 'next/head';
import { useState, useRef } from 'react';
import { US_SECTORS, CA_SECTORS, LYNCH_CATEGORIES, SECTOR_ICONS, scoreColor, scoreLabel } from '../lib/data';
import StockCard   from '../components/StockCard';
import StockModal  from '../components/StockModal';
import WelcomeScreen from '../components/WelcomeScreen';

// ── Appel vers notre route API sécurisée ──────────────────────
async function scanSector(sector, tickers, market) {
  const res = await fetch('/api/analyze', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ sector, tickers, market }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `HTTP ${res.status}`);
  }
  const data = await res.json();
  return data.stocks || [];
}

// ── Légende couleurs ──────────────────────────────────────────
const COLOR_LEGEND = [
  [0,  '#ef4444', 'Éviter'],
  [26, '#f97316', ''],
  [38, '#fb923c', 'Moyen'],
  [50, '#facc15', ''],
  [62, '#a3e635', 'Bon'],
  [72, '#4ade80', ''],
  [82, '#00e09a', 'Excellent'],
];

// ─────────────────────────────────────────────────────────────
export default function Home() {
  const [market,      setMarket]      = useState('US');
  const [selSectors,  setSelSectors]  = useState(['Technologie', 'Finance', 'Santé']);
  const [stocks,      setStocks]      = useState([]);
  const [scanning,    setScanning]    = useState(false);
  const [status,      setStatus]      = useState('');
  const [progress,    setProgress]    = useState(0);
  const [pickedStock, setPickedStock] = useState(null);
  const [sortBy,      setSortBy]      = useState('score');
  const [filterCat,   setFilterCat]   = useState('all');
  const [minScore,    setMinScore]    = useState(0);
  const [errors,      setErrors]      = useState([]);
  const abortRef = useRef(false);

  const sectors      = market === 'US' ? US_SECTORS : CA_SECTORS;
  const allSectorKeys = Object.keys(sectors);

  const switchMarket = m => {
    setMarket(m);
    setStocks([]);
    setErrors([]);
    setSelSectors(m === 'US' ? ['Technologie', 'Finance', 'Santé'] : ['Finance', 'Énergie', 'Matériaux']);
  };
  const toggleSector = s =>
    setSelSectors(p => p.includes(s) ? p.filter(x => x !== s) : [...p, s]);

  const startScan = async () => {
    if (scanning) return;
    setScanning(true); setStocks([]); setErrors([]); abortRef.current = false;
    const todo = selSectors.filter(s => sectors[s]);
    for (let i = 0; i < todo.length; i++) {
      if (abortRef.current) break;
      const sec = todo[i];
      setStatus(`Analyse en cours — ${SECTOR_ICONS[sec] || '📊'} ${sec}…`);
      setProgress(Math.round((i / todo.length) * 100));
      try {
        const results = await scanSector(sec, sectors[sec], market);
        if (!abortRef.current) setStocks(p => [...p, ...results]);
      } catch (e) {
        setErrors(p => [...p, `${sec}: ${e.message}`]);
      }
    }
    setProgress(100); setScanning(false); setStatus('');
  };

  const stopScan = () => { abortRef.current = true; setScanning(false); setStatus(''); };

  const filtered = stocks
    .filter(s => filterCat === 'all' || s.lynchCategory === filterCat)
    .filter(s => (s.score || 0) >= minScore)
    .sort((a, b) => {
      if (sortBy === 'score')  return (b.score || 0) - (a.score || 0);
      if (sortBy === 'peg')    return (a.pegRatio ?? 99) - (b.pegRatio ?? 99);
      if (sortBy === 'growth') return (b.earningsGrowth || 0) - (a.earningsGrowth || 0);
      if (sortBy === 'sector') return (a.sector || '').localeCompare(b.sector || '');
      return 0;
    });

  const topPicks = stocks.filter(s => s.score >= 80).sort((a, b) => b.score - a.score);
  const avgScore = stocks.length
    ? Math.round(stocks.reduce((acc, s) => acc + (s.score || 0), 0) / stocks.length)
    : 0;

  // ── RENDER ────────────────────────────────────────────────
  return (
    <>
      <Head>
        <title>LynchScreener — Analyse Peter Lynch temps réel</title>
        <meta name="description" content="Screener boursier basé sur la méthode Peter Lynch — marchés US et canadien" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>📡</text></svg>" />
      </Head>

      <div style={{ minHeight: '100vh', position: 'relative', zIndex: 1 }}>

        {/* ── HEADER ─────────────────────────────────────── */}
        <header style={{
          background: '#05101e', borderBottom: '1px solid #0d1f35',
          padding: '13px 22px', position: 'sticky', top: 0, zIndex: 50,
          display: 'flex', justifyContent: 'space-between', alignItems: 'center',
          flexWrap: 'wrap', gap: 12, backdropFilter: 'blur(10px)',
        }}>
          <h1 className="fn" style={{ fontSize: 19, color: '#dde6f0', letterSpacing: '-.5px', lineHeight: 1 }}>
            <span style={{ color: '#1e8fd5' }}>Lynch</span>Screener
            <span style={{ fontSize: 9, color: '#1e3a54', marginLeft: 10, fontFamily: 'DM Sans, sans-serif', fontWeight: 400, letterSpacing: 1.2, verticalAlign: 'middle', textTransform: 'uppercase' }}>
              IA · Temps réel
            </span>
          </h1>

          <div style={{ display: 'flex', alignItems: 'center', gap: 20, flexWrap: 'wrap' }}>
            {stocks.length > 0 && (
              <div style={{ display: 'flex', gap: 20 }}>
                {[
                  [stocks.length,   'Actions',    '#5a9fd4'],
                  [topPicks.length, 'Top Picks',  '#00e09a'],
                  [avgScore,        'Score moy.', scoreColor(avgScore)],
                ].map(([v, l, c]) => (
                  <div key={l} style={{ textAlign: 'center' }}>
                    <div className="fm" style={{ color: c, fontSize: 18, fontWeight: 700, lineHeight: 1 }}>{v}</div>
                    <div style={{ color: '#1e3a54', fontSize: 9, marginTop: 2, textTransform: 'uppercase', letterSpacing: .5 }}>{l}</div>
                  </div>
                ))}
              </div>
            )}
            <div className="mkt">
              <button className={`mktbtn ${market === 'US' ? 'on' : ''}`} onClick={() => switchMarket('US')}>🇺🇸 NYSE</button>
              <button className={`mktbtn ${market === 'CA' ? 'on' : ''}`} onClick={() => switchMarket('CA')}>🇨🇦 TSX</button>
            </div>
          </div>
        </header>

        {/* ── CONTROLS ───────────────────────────────────── */}
        <div style={{ background: '#05101e', borderBottom: '1px solid #0d1f35', padding: '15px 22px' }}>
          <div style={{ marginBottom: 13 }}>
            <div style={{ color: '#1e3a54', fontSize: 9, fontWeight: 600, letterSpacing: 1.2, marginBottom: 7, textTransform: 'uppercase' }}>Secteurs</div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
              {allSectorKeys.map(s => (
                <button key={s} className={`pill ${selSectors.includes(s) ? 'on' : 'off'}`} onClick={() => toggleSector(s)}>
                  {SECTOR_ICONS[s]} {s}
                </button>
              ))}
              <button
                className="pill off"
                style={{ fontStyle: 'italic' }}
                onClick={() => setSelSectors(selSectors.length === allSectorKeys.length ? [] : allSectorKeys)}
              >
                {selSectors.length === allSectorKeys.length ? '✕ Tout désélect.' : '+ Tout sélect.'}
              </button>
            </div>
          </div>

          <div style={{ display: 'flex', alignItems: 'flex-end', gap: 14, flexWrap: 'wrap' }}>
            <div>
              <div style={{ color: '#1e3a54', fontSize: 9, fontWeight: 600, letterSpacing: 1.2, marginBottom: 6, textTransform: 'uppercase' }}>Trier par</div>
              <select className="sel" value={sortBy} onChange={e => setSortBy(e.target.value)}>
                <option value="score">Score Lynch</option>
                <option value="peg">Ratio PEG</option>
                <option value="growth">Croissance</option>
                <option value="sector">Secteur</option>
              </select>
            </div>
            <div>
              <div style={{ color: '#1e3a54', fontSize: 9, fontWeight: 600, letterSpacing: 1.2, marginBottom: 6, textTransform: 'uppercase' }}>Catégorie Lynch</div>
              <select className="sel" value={filterCat} onChange={e => setFilterCat(e.target.value)}>
                <option value="all">Toutes les catégories</option>
                {Object.entries(LYNCH_CATEGORIES).map(([k, v]) => (
                  <option key={k} value={k}>{v.icon} {v.label}</option>
                ))}
              </select>
            </div>
            <div style={{ flex: 1, minWidth: 150 }}>
              <div style={{ color: '#1e3a54', fontSize: 9, fontWeight: 600, letterSpacing: 1.2, marginBottom: 6, textTransform: 'uppercase' }}>
                Score minimum :{' '}
                <span className="fm" style={{ color: scoreColor(minScore) }}>{minScore}</span>
              </div>
              <input type="range" min="0" max="80" value={minScore} onChange={e => setMinScore(+e.target.value)} />
            </div>
            <div style={{ display: 'flex', gap: 8 }}>
              <button className="scanbtn" onClick={startScan} disabled={scanning || !selSectors.length}>
                {scanning
                  ? '⟳  ANALYSE EN COURS…'
                  : `⚡  ANALYSER${selSectors.length ? ` (${selSectors.length} secteur${selSectors.length > 1 ? 's' : ''})` : ''}`}
              </button>
              {scanning && <button className="stopbtn" onClick={stopScan}>✕ Stop</button>}
            </div>
          </div>
        </div>

        {/* ── PROGRESS ───────────────────────────────────── */}
        {scanning && (
          <div style={{ background: '#081420', borderBottom: '1px solid #0d1f35', padding: '9px 22px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
              <span className="pulse" style={{ fontSize: 14 }}>⚡</span>
              <div style={{ flex: 1 }}>
                <div className="fm" style={{ color: '#5a9fd4', fontSize: 11, marginBottom: 5 }}>{status}</div>
                <div className="prog-o"><div className="prog-i" style={{ width: `${progress}%` }} /></div>
              </div>
              <span className="fm" style={{ color: '#1e3a54', fontSize: 11 }}>{progress}%</span>
            </div>
          </div>
        )}

        {/* ── ERRORS ─────────────────────────────────────── */}
        {errors.length > 0 && (
          <div style={{ background: '#160808', borderBottom: '1px solid #5f1a1a', padding: '7px 22px' }}>
            {errors.map((e, i) => (
              <div key={i} style={{ color: '#fca5a5', fontSize: 11 }}>⚠️ {e}</div>
            ))}
          </div>
        )}

        {/* ── CONTENT ────────────────────────────────────── */}
        <main style={{ padding: '22px', position: 'relative', zIndex: 1 }}>
          {stocks.length === 0 && !scanning ? (
            <WelcomeScreen />
          ) : (
            <>
              {/* Top Picks ≥ 80 */}
              {topPicks.length > 0 && (
                <div style={{ marginBottom: 28 }}>
                  <div style={{ color: '#2a4a68', fontSize: 10, fontWeight: 600, letterSpacing: 1.2, marginBottom: 12, textTransform: 'uppercase' }}>
                    ⭐ Top Picks — Score ≥ 80 ({topPicks.length})
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(255px,1fr))', gap: 13 }}>
                    {topPicks.map((s, i) => (
                      <StockCard key={s.ticker + '-top'} stock={s} idx={i} onClick={() => setPickedStock(s)} />
                    ))}
                  </div>
                  <div style={{ height: 1, background: '#0d1f35', margin: '24px 0' }} />
                </div>
              )}

              {/* Liste filtrée */}
              {filtered.length === 0 ? (
                <div style={{ textAlign: 'center', padding: 48, color: '#1e3a54' }}>
                  <div style={{ fontSize: 30, marginBottom: 8 }}>🔍</div>
                  <div style={{ fontSize: 13 }}>Aucune action ne correspond aux filtres sélectionnés</div>
                </div>
              ) : sortBy === 'sector' ? (
                [...new Set(filtered.map(s => s.sector))].map(sec => (
                  <div key={sec} style={{ marginBottom: 26 }}>
                    <div style={{ color: '#2a4a68', fontSize: 10, fontWeight: 600, letterSpacing: 1.2, marginBottom: 11, textTransform: 'uppercase' }}>
                      {SECTOR_ICONS[sec] || '📊'} {sec}
                    </div>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(255px,1fr))', gap: 13 }}>
                      {filtered.filter(s => s.sector === sec).map((s, i) => (
                        <StockCard key={s.ticker} stock={s} idx={i} onClick={() => setPickedStock(s)} />
                      ))}
                    </div>
                  </div>
                ))
              ) : (
                <>
                  <div style={{ color: '#2a4a68', fontSize: 10, fontWeight: 600, letterSpacing: 1.2, marginBottom: 12, textTransform: 'uppercase' }}>
                    {filtered.length} action{filtered.length > 1 ? 's' : ''} analysée{filtered.length > 1 ? 's' : ''}
                    {stocks.length !== filtered.length && (
                      <span style={{ color: '#1e3a54' }}> (filtrées de {stocks.length})</span>
                    )}
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(255px,1fr))', gap: 13 }}>
                    {filtered.map((s, i) => (
                      <StockCard key={s.ticker} stock={s} idx={i} onClick={() => setPickedStock(s)} />
                    ))}
                  </div>
                </>
              )}

              {/* Légende */}
              {stocks.length > 0 && (
                <div style={{ marginTop: 36, display: 'flex', alignItems: 'center', gap: 4, flexWrap: 'wrap', justifyContent: 'center' }}>
                  {COLOR_LEGEND.map(([v, c, l], i, arr) => (
                    <div key={v} style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                      <div style={{ width: 10, height: 10, borderRadius: 2, background: c }} />
                      {l && <span style={{ color: '#2a4a68', fontSize: 10 }}>{l}</span>}
                      {i < arr.length - 1 && <span style={{ color: '#102038', fontSize: 9, margin: '0 2px' }}>›</span>}
                    </div>
                  ))}
                </div>
              )}
            </>
          )}
        </main>

        {/* ── MODAL ──────────────────────────────────────── */}
        {pickedStock && <StockModal stock={pickedStock} onClose={() => setPickedStock(null)} />}
      </div>
    </>
  );
}
